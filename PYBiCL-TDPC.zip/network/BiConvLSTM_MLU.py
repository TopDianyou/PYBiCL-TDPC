import torch
from torch import nn
from typing import List, Optional, Tuple, Union

class ConvLSTMCell(nn.Module):
    def __init__(
        self,
        input_size: Tuple[int, int],
        input_dim: int,
        hidden_dim: int,
        kernel_size: Union[int, Tuple[int, int]],
        bias: bool = True,
    ):
        super().__init__()
        self.height, self.width = input_size
        self.hidden_dim = hidden_dim

        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        padding = (kernel_size[0] // 2, kernel_size[1] // 2)

        self.conv_igates = nn.Conv2d(
            input_dim + hidden_dim,
            4 * hidden_dim,  # 输入门、遗忘门、细胞门、输出门
            kernel_size,
            padding=padding,
            bias=bias,
        )

    def init_hidden(self, batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        h = torch.zeros(batch_size, self.hidden_dim, self.height, self.width, device=device)
        c = torch.zeros_like(h)
        return h, c

    def forward(
        self,
        x: torch.Tensor,
        h_prev: torch.Tensor,
        c_prev: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        combined = torch.cat([x, h_prev], dim=1)
        gates = self.conv_igates(combined)
        ingate, forgetgate, cellgate, outgate = gates.chunk(4, dim=1)

        ingate = torch.sigmoid(ingate)
        forgetgate = torch.sigmoid(forgetgate)
        cellgate = torch.tanh(cellgate)
        outgate = torch.sigmoid(outgate)

        c_next = forgetgate * c_prev + ingate * cellgate
        h_next = outgate * torch.tanh(c_next)

        return h_next, c_next

class ConvLSTM(nn.Module):
    def __init__(
        self,
        input_size: Tuple[int, int],
        input_dim: Union[int, List[int]],
        hidden_dim: Union[int, List[int]],
        kernel_size: Union[int, Tuple[int, int], List[Union[int, Tuple[int, int]]]],
        num_layers: int,
        batch_first: bool = True,
        bias: bool = True,
        return_all_layers: bool = False,
        dropout: float = 0.0,
        output_size: Optional[Union[Tuple[int, int], List[Tuple[int, int]]]] = None,
    ):
        super().__init__()
        self.input_size = input_size
        self.batch_first = batch_first
        self.return_all_layers = return_all_layers
        self.num_layers = num_layers

        self.input_dim = self._expand_param(input_dim, num_layers)
        self.hidden_dim = self._expand_param(hidden_dim, num_layers)
        self.kernel_size = self._expand_param(kernel_size, num_layers)

        default_out = output_size if output_size is not None else input_size
        self.output_sizes = self._expand_param(default_out, num_layers)

        # Resample模块
        self.resamples = nn.ModuleList()
        prev_H, prev_W = input_size
        for out_H, out_W in self.output_sizes:
            if (out_H, out_W) == (prev_H, prev_W):
                self.resamples.append(nn.Identity())
            elif out_H < prev_H and out_W < prev_W:
                self.resamples.append(nn.AdaptiveAvgPool2d((out_H, out_W)))
            else:
                self.resamples.append(nn.Upsample(size=(out_H, out_W), mode='bilinear', align_corners=False))
            prev_H, prev_W = out_H, out_W

        # 创建LSTMCell
        self.cells = nn.ModuleList()
        for i in range(num_layers):
            cell_input_size = self.output_sizes[i]
            cur_input_dim = self.input_dim[i] if i == 0 else self.hidden_dim[i - 1]
            self.cells.append(
                ConvLSTMCell(
                    input_size=cell_input_size,
                    input_dim=cur_input_dim,
                    hidden_dim=self.hidden_dim[i],
                    kernel_size=self.kernel_size[i],
                    bias=bias,
                )
            )

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(
        self,
        x: torch.Tensor,
        hidden_state: Optional[List[Tuple[torch.Tensor, torch.Tensor]]] = None,
    ) -> Tuple[List[torch.Tensor], List[Tuple[torch.Tensor, torch.Tensor]]]:
        if not self.batch_first:
            x = x.permute(1, 0, 2, 3, 4)

        batch_size, seq_len, _, _, _ = x.size()
        device = x.device

        layer_outputs, last_states = [], []
        cur_input = x

        if hidden_state is None:
            hidden_state = self._init_hidden(batch_size, device)

        for idx, cell in enumerate(self.cells):
            B, T, C, H, W = cur_input.size()
            merged = cur_input.reshape(-1, C, H, W)
            resized = self.resamples[idx](merged)
            Co, Ho, Wo = resized.shape[1:]
            layer_seq = resized.view(batch_size, T, Co, Ho, Wo)

            h, c = hidden_state[idx]
            outputs = []
            for t in range(seq_len):
                h, c = cell(layer_seq[:, t], h, c)
                outputs.append(h)
            outputs = torch.stack(outputs, dim=1)
            outputs = self.dropout(outputs)

            layer_outputs.append(outputs)
            last_states.append((h, c))
            cur_input = outputs

        if not self.return_all_layers:
            layer_outputs = layer_outputs[-1:]
            last_states = last_states[-1:]

        return layer_outputs, last_states

    def _init_hidden(self, batch_size: int, device: torch.device) -> List[Tuple[torch.Tensor, torch.Tensor]]:
        return [cell.init_hidden(batch_size, device) for cell in self.cells]

    @staticmethod
    def _expand_param(param, num_layers):
        if isinstance(param, list):
            assert len(param) == num_layers, "list param length must match num_layers"
            return param
        else:
            return [param] * num_layers

class BiConvLSTM(nn.Module):
    def __init__(
        self,
        input_size: Tuple[int, int],
        input_dim: Union[int, List[int]],
        hidden_dim: Union[int, List[int]],
        kernel_size: Union[int, Tuple[int, int], List[Union[int, Tuple[int, int]]]],
        num_layers: int,
        bidirectional: bool = True,
        batch_first: bool = True,
        bias: bool = True,
        return_all_layers: bool = False,
        dropout: float = 0.0,
        output_size: Optional[Union[Tuple[int, int], List[Tuple[int, int]]]] = None,
    ):
        super().__init__()
        self.bidirectional = bidirectional

        self.forward_lstm = ConvLSTM(
            input_size=input_size,
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            kernel_size=kernel_size,
            num_layers=num_layers,
            batch_first=batch_first,
            bias=bias,
            return_all_layers=return_all_layers,
            dropout=dropout,
            output_size=output_size,
        )
        if bidirectional:
            self.reverse_lstm = ConvLSTM(
                input_size=input_size,
                input_dim=input_dim,
                hidden_dim=hidden_dim,
                kernel_size=kernel_size,
                num_layers=num_layers,
                batch_first=batch_first,
                bias=bias,
                return_all_layers=return_all_layers,
                dropout=dropout,
                output_size=output_size,
            )

    def forward(self, x: torch.Tensor, return_sequence: bool = True):
        if not self.forward_lstm.batch_first:
            x = x.permute(1, 0, 2, 3, 4)

        fwd_out, fwd_state = self.forward_lstm(x)
        if self.bidirectional:
            rev_idx = torch.arange(x.size(1) - 1, -1, -1, device=x.device)
            x_rev = x.index_select(1, rev_idx)
            rev_out, rev_state = self.reverse_lstm(x_rev)
            rev_out = [o.index_select(1, rev_idx) for o in rev_out]
            outputs = [torch.cat([f, r], dim=2) for f, r in zip(fwd_out, rev_out)]
            states = (fwd_state, rev_state)
        else:
            outputs, states = fwd_out, (fwd_state,)

        if not return_sequence:
            outputs = [o[:, -1] for o in outputs]
        if not self.forward_lstm.return_all_layers:
            outputs = outputs[-1:]
            states = tuple(s[-1:] for s in states)

        return outputs, states

# 测试代码
if __name__ == "__main__":
    device = torch.device("cpu")
    model = BiConvLSTM(
        input_size=(64, 64),
        input_dim=128,
        hidden_dim=[128, 64, 64],
        kernel_size=[3, 3, 3],
        num_layers=3,
        bidirectional=True,
        batch_first=True,
        dropout=0.1,
        output_size=[(32, 32), (64, 64), (128, 128)],
        return_all_layers=True,
    ).to(device)
    inputs = torch.randn(2, 5, 128, 64, 64).to(device)
    outputs, states = model(inputs)
    for i, out in enumerate(outputs):
        print(f"Layer {i+1} -> shape: {out.shape}")