import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from BiConvLSTM_MLU import BiConvLSTM as BiConvGRU
import matplotlib.pyplot as plt
import numpy as np


def save_heatmap_with_background(tensor, background_img, filename, alpha=0.5):
    heatmap = tensor.mean(dim=0).detach().cpu().numpy()
    heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min() + 1e-8)
    heatmap = cv2.resize(heatmap, (background_img.shape[1], background_img.shape[0]), interpolation=cv2.INTER_LINEAR)
    heatmap = plt.cm.jet(heatmap)[:, :, :3]
    background = background_img.astype(np.float32) / 255.0
    superimposed = heatmap * alpha + background * (1 - alpha)
    plt.imsave(filename, superimposed)
    plt.close()


class FeaturePyramid(nn.Module):
    def __init__(self, in_channels=3):
        super().__init__()
        self.fp1 = nn.Sequential(nn.Conv2d(in_channels, 32, 3, 2, 1), nn.BatchNorm2d(32), nn.ReLU(inplace=True))
        self.fp2 = nn.Sequential(nn.Conv2d(32, 64, 3, 2, 1), nn.BatchNorm2d(64), nn.ReLU(inplace=True))
        self.fp3 = nn.Sequential(nn.Conv2d(64, 128, 3, 2, 1), nn.BatchNorm2d(128), nn.ReLU(inplace=True))
        self.fp4 = nn.Sequential(nn.Conv2d(128, 256, 3, 2, 1), nn.BatchNorm2d(256), nn.ReLU(inplace=True))

    def forward(self, x):
        B, t, C, H, W = x.shape
        x = x.view(B * t, C, H, W)
        f1 = self.fp1(x).view(B, t, 32, H // 2, W // 2)
        f2 = self.fp2(f1.view(B * t, 32, H // 2, W // 2)).view(B, t, 64, H // 4, W // 4)
        f3 = self.fp3(f2.view(B * t, 64, H // 4, W // 4)).view(B, t, 128, H // 8, W // 8)
        f4 = self.fp4(f3.view(B * t, 128, H // 8, W // 8)).view(B, t, 256, H // 16, W // 16)
        return f1, f2, f3, f4


class TimeEncoder(nn.Module):
    def __init__(self, time_dim=1):
        super().__init__()
        self.te1 = nn.Sequential(nn.Linear(time_dim, 32), nn.LayerNorm(32), nn.ReLU(inplace=True))
        self.te2 = nn.Sequential(nn.Linear(time_dim, 64), nn.LayerNorm(64), nn.ReLU(inplace=True))
        self.te3 = nn.Sequential(nn.Linear(time_dim, 128), nn.LayerNorm(128), nn.ReLU(inplace=True))
        self.te4 = nn.Sequential(nn.Linear(time_dim, 256), nn.LayerNorm(256), nn.ReLU(inplace=True))

    def forward(self, t, shapes):
        B, T = t.shape
        t = t.unsqueeze(-1)
        te1 = self.te1(t).view(B, T, 32, 1, 1).expand(-1, -1, -1, *shapes[0])
        te2 = self.te2(t).view(B, T, 64, 1, 1).expand(-1, -1, -1, *shapes[1])
        te3 = self.te3(t).view(B, T, 128, 1, 1).expand(-1, -1, -1, *shapes[2])
        te4 = self.te4(t).view(B, T, 256, 1, 1).expand(-1, -1, -1, *shapes[3])
        return te1, te2, te3, te4


class TransformerEncoderBlock(nn.Module):
    def __init__(self, dim=256, num_heads=8, dim_ff=1024, dropout=0.1):
        super().__init__()
        layer = nn.TransformerEncoderLayer(d_model=dim, nhead=num_heads, dim_feedforward=dim_ff, dropout=dropout, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=4)

    def forward(self, x):
        B, T, C, H, W = x.shape
        x = x.permute(0, 3, 4, 1, 2).reshape(B * H * W, T, C)
        x = self.encoder(x)
        x = x.view(B, H, W, T, C).permute(0, 3, 4, 1, 2)
        return x


class BCR1Module(nn.Module):
    def __init__(self):
        super().__init__()
        self.gru_32 = BiConvGRU((256, 192), 32, 32, 3, 1, bidirectional=True, return_all_layers=True, output_size=[(128, 96)])
        self.gru_32_bn = nn.BatchNorm2d(64)

        self.gru_64 = BiConvGRU((128, 96), 64, [64, 32], [3, 3], 2, bidirectional=True, return_all_layers=True, output_size=[(64, 48), (128, 96)])
        self.gru_64_bn = nn.ModuleList([nn.BatchNorm2d(128), nn.BatchNorm2d(64)])

        self.gru_128 = BiConvGRU((64, 48), 128, [128, 64, 32], [3]*3, 3, bidirectional=True, return_all_layers=True, output_size=[(32, 24), (64, 48), (128, 96)])
        self.gru_128_bn = nn.ModuleList([nn.BatchNorm2d(256), nn.BatchNorm2d(128), nn.BatchNorm2d(64)])

        self.gru_256 = BiConvGRU((32, 24), 256, [256, 128, 64, 32], [3]*4, 4, bidirectional=True, return_all_layers=True, output_size=[(16, 12), (32, 24), (64, 48), (128, 96)])
        self.gru_256_bn = nn.ModuleList([nn.BatchNorm2d(512), nn.BatchNorm2d(256), nn.BatchNorm2d(128), nn.BatchNorm2d(64)])

    def apply_bn_5d(self, x, bn):
        B, T, C, H, W = x.shape
        x = x.view(B * T, C, H, W)
        x = bn(x)
        x = x.view(B, T, C, H, W)
        return x

    def forward(self, ft1, ft2, ft3, ft4):
        out1 = self.gru_32(ft1)[0][-1]
        out1 = self.apply_bn_5d(out1, self.gru_32_bn)

        out2 = self.gru_64(ft2)[0]
        out2 = [self.apply_bn_5d(x, bn) for x, bn in zip(out2, self.gru_64_bn)]

        out3 = self.gru_128(ft3)[0]
        out3 = [self.apply_bn_5d(x, bn) for x, bn in zip(out3, self.gru_128_bn)]

        out4 = self.gru_256(ft4)[0]
        out4 = [self.apply_bn_5d(x, bn) for x, bn in zip(out4, self.gru_256_bn)]

        return {
            'FT-BCR11': out1,
            'FT-BCR211': out2[0], 'FT-BCR212': out2[1],
            'FT-BCR311': out3[0], 'FT-BCR312': out3[1], 'FT-BCR313': out3[2],
            'FT-BCR411': out4[0], 'FT-BCR412': out4[1], 'FT-BCR413': out4[2], 'FT-BCR414': out4[3]
        }


def fuse_stage_bcr_outputs(f128_list, f256_list, f512_list):
    return sum(f128_list), sum(f256_list), sum(f512_list)


class BCR2Module(nn.Module):
    def __init__(self):
        super().__init__()
        self.bcr64 = BiConvGRU((128, 96), 64, 64, 3, 1, bidirectional=True, output_size=[(64, 48)])
        self.bcr64_bn = nn.BatchNorm2d(128)

        self.bcr128 = BiConvGRU((64, 48), 128, 128, 3, 1, bidirectional=True, output_size=[(32, 24)])
        self.bcr128_bn = nn.BatchNorm2d(256)

        self.bcr256 = BiConvGRU((32, 24), 256, 256, 3, 1, bidirectional=True, output_size=[(16, 12)])
        self.bcr256_bn = nn.BatchNorm2d(512)

        self.bcr512 = BiConvGRU((16, 12), 512, 512, 3, 1, bidirectional=True, output_size=[(8,6)])
        self.bcr512_bn = nn.BatchNorm2d(1024)

    def apply_bn_5d(self, x, bn):
        B, T, C, H, W = x.shape
        x = x.view(B * T, C, H, W)
        x = bn(x)
        x = x.view(B, T, C, H, W)
        return x

    def forward(self, f128, f256, f512, f1024):
        o1 = self.bcr64(f128)[0][-1]
        o1 = self.apply_bn_5d(o1, self.bcr64_bn)

        o2 = self.bcr128(f256)[0][-1]
        o2 = self.apply_bn_5d(o2, self.bcr128_bn)

        o3 = self.bcr256(f512)[0][-1]
        o3 = self.apply_bn_5d(o3, self.bcr256_bn)

        o4 = self.bcr512(f1024)[0][-1]
        o4 = self.apply_bn_5d(o4, self.bcr512_bn)

        return o1, o2, o3, o4

class Predictor(nn.Module):
    def __init__(self):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.temporal_LSTM = nn.LSTM(input_size=1920, hidden_size=128, num_layers=1, batch_first=True)
        self.fc = nn.Linear(128, 1)

    def forward(self, feats):
        B, t = feats[0].shape[:2]
        pooled = [self.pool(f.view(B * t, f.shape[2], f.shape[3], f.shape[4])).view(B, t, -1) for f in feats]
        x = torch.cat(pooled, dim=2)
        out, _ = self.temporal_LSTM(x)
        pred = self.fc(out).squeeze(-1)
        return pred, feats


class PerformanceEvaluatorNet(nn.Module):
    def __init__(self, img_channels=3, time_dim=1):
        super().__init__()
        self.feature_pyramid = FeaturePyramid(img_channels)
        self.time_encoder = TimeEncoder(time_dim)
        self.transformer = TransformerEncoderBlock()
        self.bcr1 = BCR1Module()
        self.bcr2 = BCR2Module()
        self.predictor = Predictor()

    def forward(self, img_seq, time_seq):
        B, t, C, H, W = img_seq.shape
        fp1, fp2, fp3, fp4 = self.feature_pyramid(img_seq)
        te1, te2, te3, te4 = self.time_encoder(time_seq, [
            (H // 2, W // 2), (H // 4, W // 4), (H // 8, W // 8), (H // 16, W // 16)
        ])
        ft1, ft2, ft3, ft4 = fp1 + te1, fp2 + te2, fp3 + te3, fp4 + te4
        ft4_trans = self.transformer(ft4)

        bcr1_out = self.bcr1(ft1, ft2, ft3, ft4_trans)
        f128, f256, f512 = fuse_stage_bcr_outputs(
            [bcr1_out['FT-BCR11'], bcr1_out['FT-BCR212'], bcr1_out['FT-BCR313'], bcr1_out['FT-BCR414']],
            [bcr1_out['FT-BCR211'], bcr1_out['FT-BCR312'], bcr1_out['FT-BCR413']],
            [bcr1_out['FT-BCR311'], bcr1_out['FT-BCR412']]
        )
        out1, out2, out3, out4 = self.bcr2(f128, f256, f512, bcr1_out['FT-BCR411'])
        pred, feats = self.predictor([out1, out2, out3, out4])
        return pred, feats


if __name__ == '__main__':
    B, t = 21, 1
    C, H, W = 3, 512, 384
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"当前设备: {device}")

    img_seq = torch.randn(B, t, C, H, W).to(device)
    time_seq = torch.linspace(0.5, 1, steps=t).unsqueeze(0).repeat(B, 1).to(device)
    print(f"时间序列 shape: {time_seq.shape}")

    model = PerformanceEvaluatorNet(img_channels=3, time_dim=1).to(device)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"可训练参数量: {total_params / 1e6:.2f}M")

    pred, feats = model(img_seq, time_seq)
    print(f"预测结果 shape: {pred.shape}")  # 应为 (B, t)
    print("预测结果：", pred)
