# evaluation_metrics.py
import numpy as np
from fastdtw import fastdtw
from scipy.stats import pearsonr

def mae(pred, target):
    return np.mean(np.abs(pred - target))

def mse(pred, target):
    return np.mean((pred - target) ** 2)

def dtw_distance(pred, target):
    distance, _ = fastdtw(pred, target)
    return distance

def trend_accuracy(pred, target):
    pred_diff = np.diff(pred)
    target_diff = np.diff(target)
    correct = np.sum((pred_diff * target_diff) > 0)
    return correct / len(pred_diff) if len(pred_diff) > 0 else 0.0

def smoothness(pred):
    diffs = np.diff(pred)
    return np.mean(np.abs(diffs))
