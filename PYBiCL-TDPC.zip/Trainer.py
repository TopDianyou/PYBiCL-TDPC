import os
import torch
import torch.utils.data as data
from torchvision import transforms
import numpy as np
from PIL import Image
import cv2
import random

class kitti_pc_img_dataset_seq(data.Dataset):
    def __init__(self, root_path, mode='train', seq_len=5, stride=1, img_H=512, img_W=384):
        super().__init__()
        self.root_path = root_path
        self.mode = mode
        self.seq_len = seq_len
        self.stride = stride
        self.img_H = img_H
        self.img_W = img_W
        self.global_min_time, self.global_max_time = self.get_global_time_range()
        self.dataset = self.make_dataset()

    def get_global_time_range(self):
        all_times = []
        seq_list = list(range(1, 97))
        for seq in seq_list:
            calib_dir = os.path.join(self.root_path, 'calib', f'{seq:02d}')
            time_path = os.path.join(calib_dir, 'times.txt')
            if not os.path.exists(time_path):
                continue
            with open(time_path) as f:
                all_times.extend([float(line.strip()) for line in f])
        if len(all_times) == 0:
            return 0.0, 1.0
        return min(all_times), max(all_times)

    def make_dataset(self):
        dataset = []
        if self.mode == 'train':
            seq_list = list(range(1, 73))
        else:
            seq_list = list(range(74, 97))

        for seq in seq_list:
            seq_dir = os.path.join(self.root_path, 'sequence', f'{seq:02d}')
            img_folder = os.path.join(seq_dir, 'image')
            if not os.path.exists(img_folder):
                continue
            calib_dir = os.path.join(self.root_path, 'calib', f'{seq:02d}')
            time_path = os.path.join(calib_dir, 'times.txt')
            damage_path = os.path.join(calib_dir, 'damages.txt')

            if not (os.path.exists(time_path) and os.path.exists(damage_path)):
                continue

            img_files = sorted([f for f in os.listdir(img_folder) if f.endswith('.png')])
            sample_num = len(img_files)
            with open(time_path) as f:
                times = [float(line.strip()) for line in f]
            with open(damage_path) as f:
                damages = [float(line.strip()) for line in f]

            if len(times) != sample_num or len(damages) != sample_num:
                continue

            # 构建滑窗序列
            for start in range(0, sample_num - self.seq_len + 1, self.stride):
                dataset.append({
                    'seq': seq,
                    'img_paths': [os.path.join(img_folder, f"{start + i:06d}.png") for i in range(self.seq_len)],
                    'times': times[start:start + self.seq_len],
                    'damages': damages[start:start + self.seq_len],
                })
        return dataset

    def augment_img(self, img_np):
        # 随机选择增强类型
        augmentation_type = random.choice(["color", "noise", "both"])

        img = img_np.copy()

        if augmentation_type in ["color", "both"]:
            # 应用颜色增强
            color_aug = transforms.ColorJitter(
                brightness=(0.8, 1.2),
                contrast=(0.8, 1.2),
                saturation=(0.8, 1.2),
                hue=(-0.1, 0.1)
            )
            img = np.array(color_aug(Image.fromarray(img)))

        if augmentation_type in ["noise", "both"] and self.mode == 'train':
            # 转换为浮点数以便处理噪声
            img_float = img.astype(np.float32) / 255.0

            # 设置合理的噪声参数
            sigma = random.uniform(0.05, 0.08)  # 噪声标准差范围 (5%-8%)

            # 生成高斯噪声
            noise = np.random.normal(
                loc=0.0,
                scale=sigma,
                size=img.shape
            ).astype(np.float32)

            # 添加噪声并裁剪到有效范围
            noisy_img = img_float + noise
            noisy_img = np.clip(noisy_img, 0.0, 1.0)

            # 转换回0-255整数范围
            img = (noisy_img * 255.0).astype(np.uint8)

        return img

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        entry = self.dataset[idx]
        img_list = []

        for path in entry['img_paths']:
            img = cv2.imread(path)
            if img is None:
                raise FileNotFoundError(f"Image not found: {path}")
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, (self.img_W, self.img_H))

            if self.mode == 'train':
                img = self.augment_img(img)

            img_tensor = torch.from_numpy(img.astype(np.float32) / 255.).permute(2, 0, 1)
            img_list.append(img_tensor)

        # 全局归一化时间序列
        time_seq = torch.tensor(entry['times'], dtype=torch.float32)
        if self.global_max_time - self.global_min_time > 1e-6:
            time_seq = (time_seq - self.global_min_time) / (self.global_max_time - self.global_min_time)
        else:
            time_seq = torch.zeros_like(time_seq)

        return {
            'img': torch.stack(img_list),  # (T, 3, H, W)
            'time': time_seq,  # (T,)
            'damage': torch.tensor(entry['damages'], dtype=torch.float32),  # (T,)
            'seq': entry['seq']
        }
